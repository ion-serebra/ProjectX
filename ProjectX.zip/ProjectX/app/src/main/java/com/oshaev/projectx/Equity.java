package com.oshaev.projectx;

import java.util.ArrayList;

public class Equity {

    private ArrayList<Instrument> currentInstruments;

    public ArrayList<Instrument> getCurrentInstruments() {
        return currentInstruments;
    }

    public void setCurrentInstruments(ArrayList<Instrument> currentInstruments) {
        this.currentInstruments = currentInstruments;
    }
}
