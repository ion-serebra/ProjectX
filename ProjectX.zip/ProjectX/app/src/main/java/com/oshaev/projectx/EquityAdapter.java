package com.oshaev.projectx;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class EquityAdapter extends RecyclerView.Adapter<EquityAdapter.EquityViewHolder> {

    ArrayList<Instrument> instruments;

    public EquityAdapter(ArrayList<Instrument> instruments) {
        this.instruments = instruments;
    }

    @NonNull
    @Override
    public EquityAdapter.EquityViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_instrument, parent, false);
        EquityViewHolder holder = new EquityViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull EquityAdapter.EquityViewHolder holder, int position) {
        holder.ticker.setText(instruments.get(position).getTICKER());
        holder.close.setText(instruments.get(position).getCLOSE().toString());
    }

    @Override
    public int getItemCount() {
        return instruments.size();
    }

    public class EquityViewHolder extends RecyclerView.ViewHolder {

        TextView ticker;
        TextView close;
        TextView difference;

        public EquityViewHolder(@NonNull View itemView) {
            super(itemView);
            ticker = itemView.findViewById(R.id.instrumentTitleTextView);
            close = itemView.findViewById(R.id.instrumentValueTextView);
        }
    }
}
