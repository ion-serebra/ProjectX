package com.oshaev.projectx;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {



    MainActivityViewModel model;
    RecyclerView equitiesRecyclerView;
    LinearLayoutManager manager;
    EquityAdapter adapter;

    private final Handler mHandler = new Handler();
    private Runnable mTimer1;
    private Runnable mTimer2;
    private LineGraphSeries<DataPoint> mSeries1;
    private LineGraphSeries mSeries2;
    private double graph2LastXValue = 5d;
    Long timeDifference = 0L;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        model = ViewModelProviders.of(this).get(MainActivityViewModel.class);
        //FirebaseApp.initializeApp(this);
        equitiesRecyclerView = findViewById(R.id.equitiesRecyclerView);

        manager = new LinearLayoutManager(this);
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        adapter = new EquityAdapter(model.instruments);
        equitiesRecyclerView.setLayoutManager(manager);
        equitiesRecyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        //Toast.makeText(this, ""+ getTimeMinutes(20210122L, 224500L ), Toast.LENGTH_SHORT).show();

        model.getEquityData()
                .observe(this, new Observer<ArrayList<Instrument>>() {
                    @Override
                    public void onChanged(ArrayList<Instrument> equities) {
                        adapter.instruments = equities;
                        adapter.notifyDataSetChanged();



                        long prevTime = 0;
                        long currentTime = 0;
                        int i = 0;
                        Long timeMinutes = 0L;


                        for(int j = 0 ; j < equities.size() ; j++){
                            if(j>2) {

                                prevTime = getTimeMinutes(equities.get(j-1).getDATE(),
                                        equities.get(j-1).getTIME());
                                currentTime = getTimeMinutes(equities.get(j).getDATE(),
                                        equities.get(j).getTIME());

                                if(currentTime-prevTime>10)
                                {
                                    timeDifference += getTimeMinutes(equities.get(j).getDATE(),
                                        equities.get(j).getTIME())-getTimeMinutes(equities.get(j-1).getDATE(),
                                            equities.get(j-1).getTIME());
                                }

                                mSeries2.appendData(new DataPoint
                                                (getTimeMinutes(equities.get(j).getDATE(),
                                                        equities.get(j).getTIME(), timeDifference), equities.get(j).getCLOSE()),
                                        true, 100000);
                            } else {
                                mSeries2.appendData(new DataPoint
                                                (getTimeMinutes(equities.get(j).getDATE(),
                                                        equities.get(j).getTIME()), equities.get(j).getCLOSE()),
                                        true, 100000);
                            }
                        }
                    }
                });

        GraphView graph = (GraphView) findViewById(R.id.graph);
        mSeries1 = new LineGraphSeries<>();
        graph.addSeries(mSeries1);

        GraphView graph2 = (GraphView) findViewById(R.id.graph2);
        mSeries2 = new LineGraphSeries<>();
        graph2.addSeries(mSeries2);
        graph2.getViewport().setScalable(true);
        graph2.getViewport().setScrollable(true);
        graph2.getViewport().setScalableY(true);
        graph2.getViewport().setScrollableY(true);
        graph2.setTitleTextSize(10);
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMinimumFractionDigits(5);
        nf.setMinimumIntegerDigits(5);

        graph2.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(nf, nf));
        graph2.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter() {
            @Override
            public String formatLabel(double value, boolean isValueX) {

                if(isValueX) {
                    Integer dayNumber = (int) (value+timeDifference) / (60 * 24);
                    String dayOfMonth = dayNumber.toString();
                    Integer hourNumber = (int) ((value+timeDifference) - dayNumber * 60 * 24) / 60;
                    Integer minutesNumber = (int) ((value+timeDifference) - dayNumber * 60 * 24 - hourNumber * 60);

                    String result = "01." + dayOfMonth + "\n"
                            + hourNumber.toString() + " " + minutesNumber.toString();
                    return result;
                }
                else {

                    String price = value +"";
                    return price;
                }
            }
        });
        GraphView graphView = new GraphView(this);
        graphView = (GraphView) findViewById(R.id.graph);

    }





    public long getTimeMinutes(Long currentDate, Long currentTime)
    {
        String dateStr = currentDate.toString();
        String dayStr = dateStr.substring(6);
        Long dayMinutes = Long.parseLong(dayStr)*24*60;
        String hoursStr = currentTime.toString().substring(0,2);
        String minutesStr = currentTime.toString().substring(2,4);

        Long outputTime = Long.parseLong(hoursStr)*60+Long.parseLong(minutesStr)+dayMinutes;

        return outputTime;
    }

    public long getTimeMinutes(Long currentDate, Long currentTime, Long timeDifference)
    {
        String dateStr = currentDate.toString();
        String dayStr = dateStr.substring(6);
        Long dayMinutes = Long.parseLong(dayStr)*24*60;
        String hoursStr = currentTime.toString().substring(0,2);
        String minutesStr = currentTime.toString().substring(2,4);

        Long outputTime = Long.parseLong(hoursStr)*60+Long.parseLong(minutesStr)+dayMinutes-timeDifference;

        return outputTime;
    }

}
